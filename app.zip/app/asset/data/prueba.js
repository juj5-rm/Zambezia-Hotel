[
  {
    id: 1,
    name: "Prueba 1",
  },
  {
    id: 2,
    name: "Prueba 2",
  },
];
